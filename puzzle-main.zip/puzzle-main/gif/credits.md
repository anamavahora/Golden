GIF Credits: https://www.krystalcarpintieri.com/home/puzzle-animated-gifs
